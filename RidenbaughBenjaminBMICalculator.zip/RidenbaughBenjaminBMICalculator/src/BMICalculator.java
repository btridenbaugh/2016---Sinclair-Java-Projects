import java.util.Scanner;

public class BMICalculator {
	
	public static void main(String[] args) {
		
		
		Scanner value = new Scanner(System.in);
		double weight = 0;
		double height = 0;
		double BMI = 0;
		double IdealBMI = 0;
		
		
		//weight
		System.out.println("How much do you weigh (in pounds)?");
		weight = value.nextInt();
		
		//height
		System.out.println("How tall are you (in inches)?");
		height = value.nextInt();
		
		//BMI
		BMI = ((weight / (height * height)) * 703);
		System.out.println("Your BMI is " + BMI);
		
		//Ideal BMI
		System.out.println("A BMI between 20 and 24 is considered ideal. What would you like your BMI to be?");
		IdealBMI = value.nextInt();
		
		//Ideal weight
		weight = ((IdealBMI * (height * height)) / 703);
		System.out.println("Your weight needs to be " + weight + " pounds for your BMI to be " + IdealBMI);
		
	}
	

}
