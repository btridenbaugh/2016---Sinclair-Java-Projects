//Benjamin Ridenbaugh
//CIS 2212

import java.util.Scanner;

public class CalculatorWithMethods {

	public static void main(String[] args) {
		
		String repeat = "Y";
		
		//Repeats the program to redisplay the menu to the use again.
		
		while (repeat.equals("Y")){
		
		//Sets the getMenuOption method equal to the menu variable.	
			
		int menu = getMenuOption();
			
		//Displays the menu, through the usage of the variable.
		
		System.out.println(menu);
	
		
		if (menu == 1){
			
			//Performs the addition option selected through the menu.
			
			System.out.println("What is the first number? ");
			double operand1 = getOperand("What is the first number? ");
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			double add = add(operand1, operand2);
	
			System.out.println("The value of " + operand1 + " added to " + operand2 + " is " + add);
			
			
		
		}
		
		if (menu == 2){
			
			//Performs the subtraction option selected through the menu.
			
			System.out.println("What is the first number? ");
			double operand1 = getOperand("What is the first number? ");
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			double sub = subtract(operand1, operand2);
			
			System.out.println("The value of " + operand1 + " subtracted by " + operand2 + " is " + sub);
			
		}
		
		if (menu == 3){
			
			//Performs the division option selected through the menu.
			
			System.out.println("What is the first number? ");
			double operand1 = getOperand("What is the first number? ");
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			double div = divide(operand1, operand2);
			
			if (operand2 == 0){
				
				div = Double.NaN;
				
			}
			
			System.out.println("The value of " + operand1 + " divided by " + operand2 + " is " + div);
			
		}
		
		if (menu == 4){
			
			//Performs the multiplication option selected through the menu.
			
			System.out.println("What is the first number? ");
			double operand1 = getOperand("What is the first number? ");
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			double mult = multiply(operand1, operand2);
			
			System.out.println("The value of " + operand1 + " multiplied by " + operand2 + " is " + mult);
			
		}
		
		if (menu == 5){
			
			//Performs the random number generator option selected through the menu.
			
			System.out.println("What is the lower limit? ");
			double lowerLimit = getOperand("What is the lower limit? ");
			
			System.out.println("What is the upper limit? ");
			double upperLimit = getOperand("What is the upper limit? ");
			
			double rand = random(lowerLimit, upperLimit);
			
			System.out.println("The random number between " + lowerLimit + " and " + upperLimit + " is " + rand);
			
		}
		
		if (menu == 6){
			
			//Performs the quit option selected through the menu.

			System.out.println("You have decided to quit the program. It will now be terminated.");
			System.exit(0);
			
		}
		
		System.out.println(" ");
		
		repeat = "Y";
		
		}
		
	}
	
	public static int getMenuOption(){
		
		
		Scanner value = new Scanner(System.in);
		
		int choice = 0;
		
		//The for loop allows the menu to redisplay up to three times
		
		for(int i=0; i<=2; i++){
		
		System.out.println("Please choose one of the following options.");
		System.out.println("Menu");
		System.out.println("1. Addition");
		System.out.println("2. Subtraction");
		System.out.println("3. Division");
		System.out.println("4. Multiplication");
		System.out.println("5. Generate a Random Number");
		System.out.println("6. Exit the Program");
		
		choice = value.nextInt();
		
		String restart = "Y";
		
		
		if(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 ){
			
			//Breaks out of the for loop once a correct choice is made by the user.
	
			break;
		}
		else {
			
			//Notifies the user that an incorrect option was made.
			
			System.out.println(" ");
			System.out.println("That is not one of the valid options.");
		}
		if( i == 2){
			
			//Terminates the program if the user selects incorrect options three times in a row.
			
			System.out.println("You have chosen an incorrect option three times in a row, the program will now be terminated.");
			System.exit(0);
		}
		}
		return choice;
		
	}
	
	public static double getOperand(String prompt){
		
		Scanner operands = new Scanner(System.in);
		
		double operandvalue = 0;
		
		if (prompt == "What is the first number? "){
			
			//Returns the operand1 value. 
			
			operandvalue = operands.nextInt();
			return operandvalue;
			
		}
		
		if (prompt == "What is the second number? "){
			
			//Returns the operand2 value.
			
			operandvalue = operands.nextInt();
			return operandvalue;
			
		}
		
		if (prompt == "What is the lower limit? "){
			
			//Returns the lowerLimit value.
			
			operandvalue = operands.nextInt();
			return operandvalue;
			
		}
		
		if (prompt == "What is the upper limit? "){
			
			//Returns the upperLimit value.
			
			operandvalue = operands.nextInt();
			return operandvalue;
			
		}
		
		return operandvalue;

	}
	
	public static double add(double operand1, double operand2){

		//Addition method.
		
		double add = operand1 + operand2;
		
		return add;
		
	}
	
	public static double subtract(double operand1, double operand2){
		
		//Subtraction method.
		
		double subtract = operand1 - operand2;
		
		return subtract;
	}

	public static double divide(double operand1, double operand2){
		
		//Division method.
		
		double divide = operand1 / operand2;
		
		return divide;
	}
	
	
	public static double multiply(double operand1, double operand2){
		
		//Multiplication method.
		
		double multiply = operand1 * operand2;
		
		return multiply;
	}
	
	public static double random(double lowerLimit, double upperLimit){
		
		//Random Number Generating method.
		
		double random= (Math.random() * (upperLimit - lowerLimit)) + lowerLimit;
		
		return random;
	}
	

}
