//Benjamin Ridenbaugh
//CIS 2212

import java.util.Scanner;

public class MemoryCalculator {
	
	private double currentValue;

	public static void main(String[] args) {
		
		MemoryCalculator value= new MemoryCalculator();
		
		value.currentValue = 0;
		
		String repeat = "Y";
		
		//Repeats the program to redisplay the menu to the use again.
		
		while (repeat.equals("Y")){
		
		//Sets the getMenuOption method equal to the menu variable.	
			
		int menu = displayMenu();
			
		//Displays the menu, through the usage of the variable.
		
		System.out.println(menu);
	
		
		if (menu == 1){
			
			//Performs the addition option selected through the menu.
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			double add;
			
			value.add(operand2);
			
			System.out.println("The current value is " + value.currentValue);
			
			
		
		}
		
		if (menu == 2){
			
			//Performs the subtraction option selected through the menu.
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			value.subtract(operand2);
			
			System.out.println("The current value is " + value.getCurrentValue());
			
		
		}
		
		if (menu == 3){
			
			//Performs the multiplication option selected through the menu.
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
			
			value.multiply(operand2);
			
			System.out.println("The current value is " + value.getCurrentValue());
			
		}
		
		if (menu == 4){
			
			//Performs the division option selected through the menu.
			
			System.out.println("What is the second number? ");
			double operand2 = getOperand("What is the second number? ");
		
			if (operand2 == 0){
				value.currentValue = Double.NaN;
			}
			
			value.divide(operand2);
			
			System.out.println("The current value is " + value.getCurrentValue());
			
		
		}
		
		if (menu == 5){
			
			//Performs the random number generator option selected through the menu.
			
			value.clear();
			
			System.out.println("The current value is " + value.getCurrentValue());
			
		}
		
		if (menu == 6){
			
			//Performs the quit option selected through the menu.

			System.out.println("You have decided to quit the program. It will now be terminated.");
			System.exit(0);
			
		}
		
		System.out.println(" ");
		
		repeat = "Y";
		
		}
		
	}


	
	public double getCurrentValue(){
		
		return currentValue;
		
	}
	

	
	public static int displayMenu(){
		
		
		Scanner value = new Scanner(System.in);
		
		int choice = 0;
		
		//The for loop allows the menu to redisplay up to three times
		
		for(int i=0; i<=2; i++){
		
		System.out.println("Please choose one of the following options.");
		System.out.println("Menu");
		System.out.println("1. Add");
		System.out.println("2. Subtract");
		System.out.println("3. Multiply");
		System.out.println("4. Divide");
		System.out.println("5. Clear");
		System.out.println("6. Quit");
		
		choice = value.nextInt();
		
		String restart = "Y";
		
		
		if(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 ){
			
			//Breaks out of the for loop once a correct choice is made by the user.
	
			break;
		}
		else {
			
			//Notifies the user that an incorrect option was made.
			
			System.out.println(" ");
			System.out.println("That is not one of the valid options.");
		}
		if( i == 2){
			
			//Terminates the program if the user selects incorrect options three times in a row.
			
			System.out.println("You have chosen an incorrect option three times in a row, the program will now be terminated.");
			System.exit(0);
		}
		}
		return choice;
		
	}
	
	public static double getOperand(String prompt){
		
		Scanner operands = new Scanner(System.in);
		
		double operandvalue = 0;
		
		if (prompt == "What is the second number? "){
			
			//Returns the operand2 value.
			
			operandvalue = operands.nextInt();
			return operandvalue;
			
		}

		return operandvalue;

	}
	
	public void add(double operand2){

		//Addition method.
		
		double add = currentValue + operand2;
		
		currentValue = add;
		
	}
	
	public void subtract(double operand2){
		
		//Subtraction method.
		
		double subtract = currentValue - operand2;
		
		currentValue = subtract;

	}

	public void divide(double operand2){
		
		//Division method.
		
		double divide = currentValue / operand2;
		
		currentValue = divide;
		
	}
	
	
	public void multiply(double operand2){
		
		//Multiplication method.
		
		double multiply = currentValue * operand2;
		
		currentValue = multiply;
	
	}
	
	public void clear(){
		
		//Sets Current Value to 0.
		
		currentValue = 0;
		
		
	}
	

}


