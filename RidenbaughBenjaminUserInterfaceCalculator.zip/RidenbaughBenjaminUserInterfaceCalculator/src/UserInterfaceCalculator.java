
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;


	public class UserInterfaceCalculator extends Application {

		public static void main (String[] args){
			launch(args);
		}
	
		
		@Override
		public void start(Stage primaryStage){
			
			primaryStage.setTitle("Calculator");
			GridPane grid = new GridPane();
			grid.setAlignment(Pos.CENTER);
		    grid.setHgap(0);
	        grid.setVgap(0);
	        grid.setPadding(new Insets(5, 5, 5, 5));
	       
			
			
			TextField scenetitle = new TextField();
			scenetitle.setText("0.0");
			scenetitle.setEditable(false); // user can't edit

			grid.add(scenetitle, 0, 0, 5, 1);
			scenetitle.setFont(Font.font("monospace", FontWeight.NORMAL, 20));
			
			
			
			Button seven = new Button ("   7   ");
			grid.add(seven, 1, 1);
			Button eight = new Button ("   8   ");
			grid.add(eight, 2, 1);
			Button nine = new Button ("   9   ");
			grid.add(nine, 3, 1);
			Button div = new Button ("   /   ");
			grid.add(div, 4, 1);
			
			
			Button four = new Button ("   4   ");
			grid.add(four, 1, 2);
			Button five = new Button ("   5   ");
			grid.add(five, 2, 2);
			Button six = new Button ("   6   ");
			grid.add(six, 3, 2);
			Button mult = new Button ("   *   ");
			grid.add(mult, 4, 2);
 			
			
			Button one = new Button ("   1   ");
			grid.add(one, 1, 3);
			Button two = new Button ("   2   ");
			grid.add(two, 2, 3);
			Button three = new Button ("   3   ");
			grid.add(three, 3, 3);
			Button min = new Button ("   -   ");
			grid.add(min, 4, 3);
			
			
			Button clear = new Button ("   C   ");
			grid.add(clear, 1, 4);
			Button zero = new Button ("   0   ");
			grid.add(zero, 2, 4);
			Button dot = new Button ("    .    ");
			grid.add(dot, 3, 4);
			Button plus = new Button ("   +  ");
			grid.add(plus, 4, 4);
			
			
			Button equals = new Button ("                       =                      ");
			grid.add(equals, 1, 5, 5, 5);
		
	
			Scene scene = new Scene (grid, 200, 200);
			primaryStage.setScene(scene);
			primaryStage.show();
			
		}
		

	
}