//Benjamin Ridenbaugh
//CIS 2212

import java.util.Scanner;

public class BasicCalculator {

	public static void main(String[] args) {
		
		
		Scanner value = new Scanner(System.in);
		
		int choice;
		
		//Menu selection
		
		System.out.println("Please choose one of the following options on the menu.");
		System.out.println("Menu");
		System.out.println("1. Add");
		System.out.println("2. Subtract");
		System.out.println("3. Multiply");
		System.out.println("4. Divide");
		System.out.println("5. Generate Random Number");
		
		choice = value.nextInt();
		
		switch(choice){
		case 1:
			
                   //addition

			double add1;
			double add2;
			double addvalue;
			
			System.out.println("Please enter the two values you would like to add below.");
			System.out.println("Value 1:");
			add1 = value.nextDouble();
			
			System.out.println("Value 2:");
			add2 = value.nextDouble();
			
			addvalue = add1 + add2;
			
			System.out.println("The value of " + add1 +" + " + add2 +" = " + addvalue);
			break;
			
		case 2:

			//subtraction

			double sub1;
			double sub2;
			double subvalue;
			
			System.out.println("Please enter the two values you would like to subtract below.");
			System.out.println("Value 1:");
			sub1 = value.nextDouble();
			
			System.out.println("Value 2:");
			sub2 = value.nextDouble();
			
			subvalue = sub1 - sub2;
			
			System.out.println("The value of " + sub1 +" - " + sub2 +" = " + subvalue);
			break;
			
		case 3:

                   //multiplication 
			
			double multiply1;
			double multiply2;
			double multiplyvalue;
			
			System.out.println("Please enter the two values you would like to multiply below.");
			System.out.println("Value 1:");
			multiply1 = value.nextDouble();
			
			System.out.println("Value 2:");
			multiply2 = value.nextDouble();
			
			multiplyvalue = multiply1 * multiply2;
			
			System.out.println("The value of " + multiply1 +" * " + multiply2 +" = " + multiplyvalue);
			break;
			
		case 4:

                   //division 
	
			double divide1;
			double divide2;
			double dividevalue;
			
			System.out.println("Please enter the two values you would like to divide below.");
			System.out.println("Value 1:");
			divide1 = value.nextDouble();
			
			System.out.println("Value 2:");
			divide2 = value.nextDouble();
			
			if (divide2 == 0){
				
				//Division by zero scenario 
				
				System.out.println("I'm sorry you cannot divide by zero.");
				break;
			}
			
			dividevalue = divide1 / divide2;
			
			System.out.println("The value of " + divide1 +" / " + divide2 +" = " + dividevalue);
			break;
			
		case 5:

                   //random number 
			
			double randlow;
			double randhigh;
			double randvalue;
			
			System.out.println("Please enter the lower and upper limits to generate you random number between.");
			System.out.println("Lower Limit:");
			randlow = value.nextDouble();
			
			System.out.println("Upper Limit:");
			randhigh = value.nextDouble();
			
			randvalue= (Math.random() * (randhigh - randlow)) + randlow;
			
			System.out.println("The value generated between " + randlow + " and " + randhigh + " is " + randvalue);
			break;
			
		default:
			
			System.out.println("You have seleceted an incorrect option. Please re-run the program again.");
			
			
		}
		
		System.out.println("If you would like to make more calculations, please re-run the program");
		
		
	}

}
