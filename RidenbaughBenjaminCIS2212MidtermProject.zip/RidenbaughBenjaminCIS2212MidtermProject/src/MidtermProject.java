//Benjamin Ridenbaugh
//Midterm Project
//CIS 2212

import java.util.Scanner;

public class MidtermProject {                   

    public static void main(String[] args) {    
       
    	Scanner main = new Scanner(System.in);
        
    	Library track = new Library();
        
    	MediaItem item = new MediaItem();
        
    	int choice = 0;
        
    	while (choice != 5){
            
    		choice = track.displayMenu();
            
    		switch(choice){
    		
                case 1: 
                	
                	System.out.print("What is the title? ");
                    
                	item.title = main.nextLine();
                    
                	System.out.print("What is the format? ");
                    
                	item.format = main.nextLine();
                    
                	track.addNewItem(item.title, item.format);
                    
                	break;
                	
                case 2: 
                	
                	System.out.print("Which item? ");
          
                    
                	item.title = main.nextLine();
                    
                	System.out.print("Who are you loaning it to? ");
                    
                	item.loanedTo = main.nextLine();
                    
                	System.out.print("When did you loan the item? ");
                    
                	item.dateLoaned = main.nextLine();
                    
                	track.markItemOnLoan(item.title, item.loanedTo, item.dateLoaned);
                    
                	break;
                	
                case 3: 
                	
                	track.listAllItems();
                        
                	break;
                	
                case 4: 
                	
                	System.out.println("Which item? ");
                    
                	item.title = main.nextLine();
                    
                	track.markItemReturned(item.title);
                    
                	break;
                	
                case 5: 
                	
                	System.out.println("Goodbye");
                	
            }
        }
    	
        main.close();
    }
}
class MediaItem {
	//fields
    String title;   
    String format;
    boolean onLoan;
    String loanedTo;
    String dateLoaned;

    MediaItem(){              
    	
    	title = null;
        format = null;
        onLoan = false;
        loanedTo = null;
        dateLoaned = null;
    }
    
    MediaItem(String title, String format){         
    	
        onLoan = false;
        this.title = title;
        this.format = format;
    }


    void markOnLoan(String name, String date){      
    	//methods
            
    	if(onLoan == true)
                
    		System.out.println(this.title + " is already loaned out");
            
    	else {
                    onLoan = true;
                    loanedTo = name;
                    dateLoaned = date;
            }
    }
    void markReturned(){
    	
        if(onLoan == false)
         
        	System.out.println(this.title + " is not currently loaned out");
        
        onLoan = false; 
    }
}
 class Library{
	 
     static Scanner in = new Scanner(System.in);    
     
     MediaItem t = new MediaItem();
     
     MediaItem[] items = new MediaItem[100];
     
     String[] str = new String[100];
     
     int numberOfItems = 0;                        
     //fields
     int check = 0;
     int called = 0;

     int displayMenu(){                             
    	 //methods
         
    	 System.out.println("1. Add new item \n2. Mark an item as on loan \n3. List all items \n4. Mark an item as returned \n5. Quit");     
         
    	 System.out.print("What would you like to do? ");
         
    	 int a = in.nextInt();
         
    	 return a;
     }
     
     void addNewItem(String title, String format){
         
    	 MediaItem item = new MediaItem(title, format);
         
    	 items[numberOfItems] = item;
         
    	 numberOfItems++; 
     }
     
     void markItemOnLoan(String title, String name, String date){
         
    	 for(int b = 0; b < numberOfItems; b++){
             
    		 if(title.equals(items[b].title)){
                 
    			 items[b].markOnLoan(name, date);
                 
    			 called = 1;
             }
         }
             if(called == 0)
                 
            	 System.out.println(title + " doesn't exist");  
             
             called = 0;
     }
     void listAllItems(){
        for(int c = 0; c < numberOfItems; c++){
            
        	if (items[c].onLoan)
                
        		str[c] = "\n" + items[c].title + " (" + items[c].format + ")" + " loaned to " + items[c].loanedTo + " on " + items[c].dateLoaned;
            
        	else
                
        		str[c] = "\n" + items[c].title + " (" + items[c].format + ")";
            
        	System.out.println(str[c] + "\n");
        }
     }
     void markItemReturned(String title){
         
    	 for(int b = 0; b < numberOfItems; b++){
             
    		 if(title.equals(items[b].title)){
                 
    			 items[b].markReturned();
                 
    			 check = 1;
             }      
         }
         if(check == 0)
             
        	 System.out.println("Sorry, I couldn't find " + title + " in the library.");
         
         check = 0;
     }
 }  
