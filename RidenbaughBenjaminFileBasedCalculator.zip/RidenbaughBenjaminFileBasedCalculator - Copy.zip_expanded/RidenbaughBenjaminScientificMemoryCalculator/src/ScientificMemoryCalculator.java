
public class ScientificMemoryCalculator extends MemoryCalculator {
	

	
}
