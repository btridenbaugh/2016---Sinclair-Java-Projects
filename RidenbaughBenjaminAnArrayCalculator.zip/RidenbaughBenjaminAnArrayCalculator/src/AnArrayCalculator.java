//Benjamin Ridenbaugh	
//CIS 2212

import static java.lang.System.out;

import java.util.Scanner;

public class AnArrayCalculator {

	public static Scanner option = new Scanner(System.in);

	public static int getMenuOption() {

		out.println("Menu \n1. Add \n2. Subtract \n3. Multiply \n4. Divide "
				+ "\n5. Dot Product" + "\n6. Generate Random Number \n7. Quit");
		out.println("What would you like to do: ");

		int num4 = option.nextInt();

		while ((num4 < 1 || num4 > 6) && num4 != 7) {
			out.println("Please the enter the options 1,2,3,4,5,6 or 7: ");
			num4 = option.nextInt();
		}
		return num4;
	}

	public static double getOperand(String prompt) {

		out.println(prompt);
		return option.nextDouble();

	}

	public static int getSize(String prompt) {
		out.println(prompt);
		return option.nextInt();
	}

	public static double[] getOperand(String prompt, int size) {

		double[] oprnd = new double[size];
		out.println(prompt);
		for (int i = 0; i < size; i++)
			oprnd[i] = option.nextDouble();// double value
		return oprnd;

	}

	public static double[] add(double[] operand1, double[] operand2) {
		double[] ans = new double[operand1.length];
		for (int i = 0; i < operand1.length; i++)
			ans[i] = operand1[i] + operand2[i];// ADD elements
		return ans;

	}

	public static double[] subtract(double[] operand1, double[] operand2) {
		double[] ans = new double[operand1.length];
		for (int i = 0; i < operand1.length; i++)
			ans[i] = operand1[i] - operand2[i];// subtracts elements
		return ans;

	}

	public static double[] multiply(double[] operand1, double[] operand2) {

		double[] ans = new double[operand1.length];
		for (int i = 0; i < operand1.length; i++)
			ans[i] = operand1[i] * operand2[i];// multiplies elements
		return ans;

	}

	public static double[] divide(double[] operand1, double[] operand2) {
		double[] ans = new double[operand1.length];
		for (int i = 0; i < operand1.length; i++)
			if (operand2[i] == 0) // division by 0 exception
				ans[i] = Double.NaN; //displays value "NaN"
			else
				ans[i] = operand1[i] / operand2[i];

		return ans;

	}

	public static double[] random(double lowerLimit, double upperLimit, int size) {
		double[] ans = new double[size];
		for (size = 0; size < ans.length; size++)

			ans[size] = Math.random() * (upperLimit - lowerLimit) + lowerLimit;// ransom numbers
		return ans;
	}

	public static double dotProduct(double[] operand1, double[] operand2) {
		double ans = 0;
		for (int i = 0; i < operand1.length; i++)
		{
			ans += operand1[i] * operand2[i];// multiplication
		}
		return ans;

	}

	public static void main(String[] args) {
		int chose, size = 0;
		double x = 0, y = 0, z = 0;
		double[] op1, op2;// operands
		
		while (true) {
			chose = getMenuOption();

			switch (chose) {
			
			case 1:
				
				//Addition option
				
				size = getSize("How many values are in the arrays?");
				op1 = getOperand(
						"Enter the values in the first array, separated by spaces:",
						size);
				op2 = getOperand(
						"Enter the values in the second array, separated by spaces:?",
						size);
				double[] ans = new double[size]; //Answer array
				ans = add(op1, op2);
				out.println("The result is ");
				for (int i = 0; i < size; i++)
					out.print("[" + ans[i] + "]\n"); //output
				break;
				
			case 2:
				
				//Subtraction option
				
				size = getSize("How many values are in the arrays?");
				op1 = getOperand(
						"Enter the values in the first array, separated by spaces:",
						size);
				op2 = getOperand(
						"Enter the values in the second array, separated by spaces:?",
						size);
				ans = subtract(op1, op2);
				out.println("The result is ");
				for (int i = 0; i < size; i++)
					out.print("[" + ans[i] + "]\n");
				break;
				
			case 3:
				
				//Multiplication option
				
				size = getSize("How many values are in the arrays?");
				op1 = getOperand(
						"Enter the values in the first array, separated by spaces:",
						size);
				op2 = getOperand(
						"Enter the values in the second array, separated by spaces:?",
						size);
				ans = multiply(op1, op2);
				out.println("The result is ");
				for (int i = 0; i < size; i++)
					out.print("[" + ans[i] + "]\n");
				break;
				
			case 4:
				
				//Division option
				
				size = getSize("How many values are in the arrays?");
				op1 = getOperand(
						"Enter the values in the first array, separated by spaces:",
						size);
				op2 = getOperand(
						"Enter the values in the second array, separated by spaces:?",
						size);
				ans = divide(op1, op2);
				out.println("The result is ");
				for (int i = 0; i < size; i++)
					out.print("[" + ans[i] + "]\n");
				break;
				
			case 5:
				
				//Dot product option
				
				size = getSize("How many values are in the arrays?");
				op1 = getOperand(
						"Enter the values in the first array, separated by spaces:",
						size);
				op2 = getOperand(
						"Enter the values in the second array, separated by spaces:?",
						size);
				x = dotProduct(op1, op2);
				out.println("The result is " + x + "\n");
				break;
				
			case 6:
				
				//Random number option
				
				size = getSize("How many values are in the arrays?");
				y = getOperand("What is the lower limit for the random number");
				z = getOperand("What is the lower limit for the random number");
				ans = random(y, z, size);
				out.println("The result is ");
				for (int i = 0; i < size; i++)
					out.print("[" + ans[i] + "]\n");
				break;

			case 7:
				
				out.println("Goodbye!");
				System.exit(0);

			default:
				out.println("I'm sorry, " + " wasn't one of the options");
				break;

			}

		}
	}
}