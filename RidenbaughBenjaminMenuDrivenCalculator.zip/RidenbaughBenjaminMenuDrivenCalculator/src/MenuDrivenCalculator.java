//Benjamin Ridenbaugh
//CIS 2212

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		
		Scanner value = new Scanner(System.in);
		
		int choice = 0;
		
		//This program is a basic calculator, which can solve basic mathematical functions like addition, 
		//subtraction, division, multiplication, as well as generating a random number.
		
		String letter = "Y";
		
		while (letter.equals("Y")) {
		
		//The while loops allows the program to restart after user completes a correct option
			
		for(int i=0; i<=2; i++){
		
		//The for loop allows the menu to redisplay up to three times
		
		System.out.println("Please choose one of the following options.");
		System.out.println("Menu");
		System.out.println("1. Add");
		System.out.println("2. Subtract");
		System.out.println("3. Multiply");
		System.out.println("4. Divide");
		System.out.println("5. Generate a Random Number");
		System.out.println("6. Quit");
		
		choice = value.nextInt();
		
		if(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 ){
			
			//Breaks out of the for loop once a correct choice is made by the user.
	
			break;
		}
		if( i == 2){
			
			//Terminates the program if the user selects incorrect options three times in a row.
			
			System.out.println("You have chosen an incorrect option three times, the program will now be terminated.");
			System.exit(0);
		}
		}
		
		switch(choice){
		case 1:
			
                   //addition

			double add1;
			double add2;
			double addvalue;
			
			System.out.println("Please enter the two values you would like to add below.");
			System.out.println("Value 1:");
			add1 = value.nextDouble();
			
			System.out.println("Value 2:");
			add2 = value.nextDouble();
			
			addvalue = add1 + add2;
			
			System.out.println("The value of " + add1 +" + " + add2 +" = " + addvalue);
			break;
			
		case 2:

			//subtraction

			double sub1;
			double sub2;
			double subvalue;
			
			System.out.println("Please enter the two values you would like to subtract below.");
			System.out.println("Value 1:");
			sub1 = value.nextDouble();
			
			System.out.println("Value 2:");
			sub2 = value.nextDouble();
			
			subvalue = sub1 - sub2;
			
			System.out.println("The value of " + sub1 +" - " + sub2 +" = " + subvalue);
			break;
			
		case 3:

                   //multiplication 
			
			double multiply1;
			double multiply2;
			double multiplyvalue;
			
			System.out.println("Please enter the two values you would like to multiply below.");
			System.out.println("Value 1:");
			multiply1 = value.nextDouble();
			
			System.out.println("Value 2:");
			multiply2 = value.nextDouble();
			
			multiplyvalue = multiply1 * multiply2;
			
			System.out.println("The value of " + multiply1 +" * " + multiply2 +" = " + multiplyvalue);
			break;
			
		case 4:

                   //division 
	
			double divide1;
			double divide2;
			double dividevalue;
			
			System.out.println("Please enter the two values you would like to divide below.");
			System.out.println("Value 1:");
			divide1 = value.nextDouble();
			
			System.out.println("Value 2:");
			divide2 = value.nextDouble();
			
			dividevalue = divide1 / divide2;
			
			System.out.println("The value of " + divide1 +" / " + divide2 +" = " + dividevalue);
			break;
			
		case 5:
			
			//Random Number Generator choice
			
			double randlow;
			double randhigh;
			double randvalue;
			
			System.out.println("Please enter the lower and upper limits to generate you random number between.");
			System.out.println("Lower Limit:");
			randlow = value.nextDouble();
			
			System.out.println("Upper Limit:");
			randhigh = value.nextDouble();
			
			randvalue= (Math.random() * (randhigh - randlow)) + randlow;
			
			System.out.println("The value generated between " + randlow + " and " + randhigh + " is " + randvalue);
			break;
			
		case 6: 
			
			//Quit choice. Terminates the program
			
			System.out.println("You have chosen to quit the program. It will now be terminated.");
			System.exit(0);
			
			
		}
		
		//After an option is completed, this redisplays the menu to allow the user to run the program again.
		letter = "Y";
		
		}
	}


}


