//Benjamin Ridenbaugh
//CIS 2212
//September 8, 2016

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Scanner;

import javax.swing.JFileChooser;

import java.util.ArrayList;

public class MemoryCalculator{
	
	public double currentValue;

	ArrayList<String> arraylist = new ArrayList<String>();

	
	public double getCurrentValue(){
		
		return currentValue;
		
	}
	
	public void setCurrentValue(double currentValue) {
		
		this.currentValue = currentValue;
	}

	
	public int displayMenu(){
		
		
		Scanner value = new Scanner(System.in);
		
		int choice = 0;
		
		//The for loop allows the menu to redisplay up to three times
		
		for(int i=0; i<=2; i++){
		
		System.out.println("Please choose one of the following options.");
		System.out.println("Menu");
		System.out.println("1. Add");
		System.out.println("2. Subtract");
		System.out.println("3. Multiply");
		System.out.println("4. Divide");
		System.out.println("5. Power");
		System.out.println("6. Logarithm");
		System.out.println("7. Clear");
		System.out.println("8. Save");
		System.out.println("9. Quit");
		
		
		choice = value.nextInt();
		
		String restart = "Y";
		
		
		if(choice == 1 || choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 7 || choice == 8){
			
			//Breaks out of the for loop once a correct choice is made by the user.
	
			break;
		}
		
		if (choice == 9) {
			System.out.println("Goodbye!");
			System.exit(0);
		}
		
		else {
			
			//Notifies the user that an incorrect option was made.
			
			System.out.println(" ");
			System.out.println("That is not one of the valid options.");
		}
		if( i == 2){
			
			//Terminates the program if the user selects incorrect options three times in a row.
			
			System.out.println("You have chosen an incorrect option three times in a row, the program will now be terminated.");
			System.exit(0);
		}
		}
		return choice;
		
	}
	
	public double getOperand(String prompt){
		
		Scanner operands = new Scanner(System.in);
		
		System.out.print(prompt);
		
		return operands.nextDouble();

	}
	
	public void add(double operand2){

		arraylist.add(currentValue + " + " + operand2 + " = ");
		
		//Addition method.
		
		double add = currentValue + operand2;
		
		currentValue = add;
		
		arraylist.add(currentValue + " , ");
		
		
	}
	
	public void subtract(double operand2){
		
		arraylist.add(currentValue + " - " + operand2 + " = ");
		
		//Subtraction method.
		
		double subtract = currentValue - operand2;
		
		currentValue = subtract;

		arraylist.add(currentValue + " , ");
		
	}

	public void divide(double operand2){
		
		arraylist.add(currentValue + " / " + operand2 + " = ");
		
		//Division method.
		
		double divide = currentValue / operand2;
		
		currentValue = divide;
		
		arraylist.add(currentValue + " , ");
		
	}
	
	
	public void multiply(double operand2){
		
		arraylist.add(currentValue + " * " + operand2 + " = ");
		
		//Multiplication method.
		
		double multiply = currentValue * operand2;
		
		currentValue = multiply;
	
		arraylist.add(currentValue + " , ");
		
	}
	
	public void clear(){
		
		arraylist.add("Cleared");
		
		//Sets Current Value to 0.
		
		currentValue = 0;
		
		arraylist.add(" , ");
		
		
	}

	public void power (double operand2){
		
		arraylist.add(currentValue + " ^ " + operand2 + " = ");
		
		double power = Math.pow(currentValue, operand2);
		
		currentValue = power;
		
		arraylist.add(currentValue + " , ");
		
		
	}
	
	public void log (double operand2){
	
		arraylist.add("The log of " + currentValue + " = ");
		
		double log = Math.log(currentValue);
		
		currentValue = log;
		
		arraylist.add(currentValue + " , ");
		
		
	}
	
	public void save () throws IOException{
		FileWriter writer = new FileWriter("output.txt"); 
		for(String str: arraylist) {
		  writer.write(str);
		}
		writer.close();	
	}
	}


