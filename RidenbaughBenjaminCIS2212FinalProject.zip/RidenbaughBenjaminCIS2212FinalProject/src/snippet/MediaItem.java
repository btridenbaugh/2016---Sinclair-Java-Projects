package snippet;
public class MediaItem {
	private String title;  
	private String format;
	private boolean onLoan = false;
	private String loanedTo;
	private String dateLoaned;

	public MediaItem() {
		
	}

	public MediaItem(String title, String format) {
		this.title = title; 
		this.format = format;
	}

	public void setTitle(String title) { 
		this.title = title;
		
	}

	public String getTitle() {
		return title;
	}

	public void setFormat(String format) { 
		this.format = format;
		
	}

	public String getFormat() { 
		return format;
	}

	public void setonLoan(boolean onLoan) {
		this.onLoan = onLoan;
		
	}

	public boolean getonLoan() {
		return onLoan;

	}

	public String getDateLoaned() {
		return dateLoaned;

	}

	public void setDateLoaned(String dateLoaned) {
		this.dateLoaned=dateLoaned;
	
	}
	public String getLoanedTo() {
		return this.loanedTo;
	}
	public void setLoanedTo(String name) {
		this.loanedTo=name;

	}
	public void markOnLoan(String name, String date) {
		this.setonLoan(true);
		this.setDateLoaned(date);
		this.setLoanedTo(name);
	}

	public void markReturned() {
		this.setonLoan(false);
	}
}





