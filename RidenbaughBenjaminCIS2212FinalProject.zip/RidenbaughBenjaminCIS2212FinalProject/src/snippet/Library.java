package snippet;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Optional;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;

public class Library {
	public ArrayList<MediaItem> list2 = new ArrayList<MediaItem>();

	static int itemsCount = 0;

	static String title;
	static String format;
	static String name;
	static String StringAdded;
	static String date;

	//Adds a new Item
	
	public void addNewItem() {
		MediaItem m1 = new MediaItem();
		String name = null, format = null;
		
		TextInputDialog dialog = new TextInputDialog();
		dialog.setTitle("Item Entry");
		dialog.setHeaderText(null);
		dialog.setContentText("Name of Item: ");
		Optional<String> result = dialog.showAndWait();
		if (result.isPresent()) {
			title = result.get();
		}
		m1.setTitle(title);
		dialog.getEditor().clear();
		dialog.setContentText("Format type: ");
		result = dialog.showAndWait();
		if (result.isPresent()) {
			format = result.get();

		}
		
		m1.setFormat(format); // set

		list2.add(m1);

	}

	// Marks the Item on loan

	public void markItemOnLoan(String title) {
		for (int i = 0; i < list2.size(); i++) {
			MediaItem m = list2.get(i);
			if (m.getTitle().trim().equals(title)) {

				TextInputDialog dialog = new TextInputDialog();
				dialog.setTitle("Item Loaning");
				dialog.setHeaderText(null);
				dialog.setContentText("Who are you loaning it to (name)?: ");
				Optional<String> result = dialog.showAndWait();
				if (result.isPresent()) {
					name = result.get();
					System.out.println(name);
				}
				m.setTitle(title);// same title is set by the object
				dialog.getEditor().clear();
				dialog.setContentText("When did you loan it (date)?: ");
				result = dialog.showAndWait();
				if (result.isPresent()) {
					date = result.get();
					System.out.println(date);
				}
				
				m.markOnLoan(name, date);
				
				return;

			}
		}

	}

	//Lists all Items
	
	public ArrayList<String> listAllItems() {

		ArrayList<String> items = new ArrayList<String>();

		for (int i = 0; i < list2.size(); i++) {
			MediaItem m = list2.get(i);
			String loanedTo = "   ", date = "    ";
			if (m.getonLoan()) {

				if (m.getLoanedTo() != null) {
					loanedTo = " loaned to " + m.getLoanedTo();

					date = " on " + m.getDateLoaned();
				}

			}

			items.add(m.getTitle() + "(" + m.getFormat() + ")" + loanedTo
					+ date);

		}
		return items;

	}

	//Returns Item
	
	public void markItemReturned(String title) {
		for (int i = 0; i < list2.size(); i++) {
			MediaItem m = list2.get(i);
			if (m.getonLoan() && m.getTitle().trim().equals(title)) {
				m.markReturned();
				return;
			}
		}
	}

	//Deletes Item
	
	public void delete(String title) {
		for (int i = 0; i < list2.size(); i++) {
			MediaItem m = list2.get(i);
			if (m.getTitle().trim().equals(title)) {
				list2.remove(i);
				return;
			}
		}
	}
	
	//Saves Text FIle

	public void save() throws FileNotFoundException {
		PrintWriter writer = new PrintWriter("library.txt");
		String item;
		for (int i = 0; i < list2.size(); i++) {
			MediaItem m = list2.get(i);
			item = m.getTitle() + "#" + m.getFormat() + "#" + m.getonLoan()
					+ "#" + m.getLoanedTo() + "#" + m.getDateLoaned();

			writer.println(item);
		}
		writer.close();

	}
	
	//Opens Text File

	public void open() {
		int count = 0;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("library.txt"));
		} catch (FileNotFoundException e) {

			Label dialog = new Label("Library.txt is not found");
		}
		try {

			String strLine = br.readLine();
			while (strLine != null) {
				count++;
				String title, loanTo, date, format, text;
				boolean loaned;
				MediaItem m = new MediaItem();

				int begX = 0, endX = strLine.indexOf("#", begX);
				text = strLine.substring( begX, endX);
				if (text.equals("null")) {
					title = "";
				} else
					title = text;
					begX = endX++;
					endX = strLine.indexOf("#", begX + 1);
					text = strLine.substring(begX + 1, endX);
				if (text.equals("null")) {
					format = "null";
				} else
					format = text;
					begX = endX++;
					endX = strLine.indexOf("#", begX + 1);
					text = strLine.substring(begX + 1, endX);
				if (text.equals("null")) {
					loaned = false;
				} else if (text.equals("true"))
					loaned = true;
				else
					loaned = false;
					begX = endX++;
					endX = strLine.indexOf("#", begX + 1);
					text = strLine.substring(begX + 1, endX);
				if (text.equals("null")) {
					loanTo = "null";
				} else
					loanTo = text;
					begX = endX++;
					text = strLine.substring(begX + 1);
				if (text.equals("null")) {
					date = "";
				} else
					date = text;
				//System.out.println(begX + 1 + " " + date);
				m.setTitle(title);
				m.setFormat(format);
				m.setLoanedTo(loanTo);
				m.setonLoan(loaned);
				m.setDateLoaned(date);
				list2.add(m);
				strLine = br.readLine();
			}

			br.close();

		} catch (IOException e) {
			Label dialog = new Label("IOError");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}



