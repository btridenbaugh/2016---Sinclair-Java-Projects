//Benjamin Ridenbaugh
//CIS 2212
//05/01/2019
package snippet;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class LibraryGUI extends Application {
	
	private Library library = new Library();
	private static Button addItemBt = new Button("Add");
	private static Button checkOutBt = new Button("Check Out");
	private static Button checkInBt = new Button("Check In");
	private static Button deleteBt = new Button("Delete");
	private ListView<String> list = new ListView<String>();
	public static ListView<String> listPanel;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		//Sets up the window
		
		HBox buttonPanel = new HBox();
		buttonPanel.getChildren().addAll(addItemBt, checkOutBt, checkInBt, deleteBt);
		buttonPanel.setAlignment(Pos.CENTER);
		buttonPanel.setSpacing(15);
		
		library.open(); //Opens the text file to be displayed
		
		list = new ListView<String>();
		list.setEditable(true);
		ObservableList<String> allItems = FXCollections.observableArrayList(library.listAllItems());
		list.setItems(allItems);
		
		allItems.addListener((ListChangeListener<Object>) change -> {
			System.out.println("ListView updated");
		});
		
		BorderPane bPane = new BorderPane();
		BorderPane.setAlignment(list, Pos.TOP_LEFT);
		BorderPane.setMargin(list, new Insets(12,12,6,12));
		BorderPane.setMargin(buttonPanel, new Insets(0,6,6,6));
		bPane.setCenter(list);
		bPane.setBottom(buttonPanel);

		//Button Click controls
		
		addItemBt.setOnAction(e -> {
			addNewItem();
			list.setItems(FXCollections.observableArrayList(library.listAllItems()));
		});
		
		checkOutBt.setOnAction(e -> {
			checkOutItem();
			list.setItems(FXCollections.observableArrayList(library.listAllItems()));
		});
		checkInBt.setOnAction(e -> {
			checkInItem();
			list.setItems(FXCollections.observableArrayList(library.listAllItems()));
		});
		
		deleteBt.setOnAction(e -> {
			deleteItem();
			list.setItems(FXCollections.observableArrayList(library.listAllItems()));
		});

		Scene scene = new Scene(bPane, 500, 500);
		
		primaryStage.setTitle("My Library");
		primaryStage.setScene(scene);
		primaryStage.setWidth(bPane.getWidth());
		primaryStage.setHeight(bPane.getHeight());
		primaryStage.setResizable(false);
		primaryStage.show();
		
		primaryStage.setOnCloseRequest(e -> {
			try {
				library.save();
			} catch (Exception e1) {
				System.out.println("File save error");
			}
		});
		
	}
	
	//Breaks to Add Item in Library
	
	public void addNewItem() {
		library.addNewItem();
	}
	
	//Breaks to Mark Out in Library
	
	public void checkOutItem() {
		Object selected = list.getSelectionModel().getSelectedItem(); //This uses teh currently selected list value
		if (selected != null) {
			String s = selected.toString();
			String title = s.substring(0, s.lastIndexOf("("));
			title.trim();
			library.markItemOnLoan(title);// markIteamOnLoan is called
			String[] items = new String[library.list2.size()];
			library.listAllItems().toArray(items);
		}
	}
	
	//Breaks to Return Item in Library
	
	public void checkInItem() {
		Object selected = list.getSelectionModel().getSelectedItem();
		if (selected != null) {
			String s = selected.toString();
			String title = s.substring(0, s.lastIndexOf("("));
			title.trim();
			library.markItemReturned(title);//markItemReturned is called
			String[] items = new String[library.list2.size()];
			library.listAllItems().toArray(items);
		}
	}
	
	//Breaks to Delete Item in Library
	
	public void deleteItem() {
		Object selected = list.getSelectionModel().getSelectedItem();
		if (selected != null) {
			String s = selected.toString();
			String title = s.substring(0, s.lastIndexOf("("));
			title.trim();
			library.delete(title);//delete method is called
			String[] items = new String[library.list2.size()];
			library.listAllItems().toArray(items);

		}
	}
	

	public static void main(String[] args) {
		Application.launch(args);
	}
}
