//Benjamin Ridenbaugh
//CIS 2212
//Arabic to Roman Numeral converter


import java.util.Scanner;

public class ConvertArabicNumerals {

	public static void main(String[] args) {
	
		String repeat = "y";
		
		while (repeat.equals("y")){
			
		//repeats the prompt, until user chooses to stop.
			 
		Scanner number = new Scanner (System.in);
		
		int arabic = 0;
	
		System.out.println("Enter the value you would like to convert to a Roman Numeral, or enter -1 to quit.");
		arabic = number.nextInt();
		
		//inputs values user would like to convert to roman numerals.
		
	    if (arabic < -1 || arabic == 0  || arabic > 3999){
	        
	    	//resets the loop, if the user inputs an invalid number.
	    	
	    	System.out.println("Please enter a valid number between 1 and 3999, or enter -1 to quit.");
	        
	    	continue;
	        
	    }
	    if ( arabic == -1){
	    	
	    	 //terminates the program if selected.
	    	
	    	System.exit(0);
	    
	    }
	    
	    else{
	    
	    //transfers number value to the arabitToRoman method below, and then prints the String returned.
	    	
		String num = arabicToRoman(arabic) ;
	 
		System.out.println(num);
		
	    }
		
		}

	}

	public static String arabicToRoman ( int arabic ){

			//takes the value entered, and applies all conditions satisfied, then returns the String to the main method.
		
		    String num = "";
		    
		    while (arabic >= 1000) {
		    	
		        num += "M";
		        
		        arabic -= 1000;
		        
		    }
		    while (arabic >= 900) {
		    	
		        num += "CM";
		        
		        arabic -= 900;
		        
		    }
		    while (arabic >= 500) {
		        
		    	num += "D";
		    	
		        arabic -= 500;
		        
		    }
		    while (arabic >= 400) {
		        
		    	num += "CD";
		    	
		        arabic -= 400;
		        
		    }
		    while (arabic >= 100) {
		        
		    	num += "C";
		        
		        arabic -= 100;
		        
		    }
		    while (arabic >= 90) {
		        
		    	num += "XC";
		    	
		        arabic -= 90;
		        
		    }
		    while (arabic >= 50) {
		        
		    	num += "L";
		    	
		        arabic -= 50;
		        
		    }
		    while (arabic >= 40) {
		        
		    	num += "XL";
		    	
		        arabic -= 40;
		        
		    }
		    while (arabic >= 10) {
		        
		    	num += "X";
		    	
		        arabic -= 10;
		        
		    }
		    while (arabic >= 9) {
		        
		    	num += "IX";
		    	
		        arabic -= 9;
		        
		    }
		    while (arabic >= 5) {
		        
		    	num += "V";
		    	
		        arabic -= 5;
		        
		    }
		    while (arabic >= 4) {
		        
		    	num += "IV";
		    	
		        arabic -= 4;
		        
		    }
		    while (arabic >= 1) {
		        
		    	num += "I";
		    	
		        arabic -= 1;
		        
		    }    
		    return num;
		
}
}
